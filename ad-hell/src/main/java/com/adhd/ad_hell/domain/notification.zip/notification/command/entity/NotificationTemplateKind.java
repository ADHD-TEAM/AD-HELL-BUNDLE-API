package com.adhd.ad_hell.domain.notification.command.entity;

public enum NotificationTemplateKind {
    NORMAL,
    EVENT
}