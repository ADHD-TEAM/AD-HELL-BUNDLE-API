package com.adhd.ad_hell.domain.notification.command.domain.aggregate.enums;

public enum NotificationScheduleStatus {
    SCHEDULED,
    COMPLETED,
    CANCELLED,
    FAILED
}