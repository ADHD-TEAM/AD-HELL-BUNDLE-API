package com.adhd.ad_hell.domain.report.command.domain.aggregate;

public enum ReportStatus {
  REQUEST, COMPLETE
}
