package com.adhd.ad_hell.domain.inquiry.command.application.dto.response;

public class InquiryCommandResponse {

    private Long Id;
    private String Title;
    private String content;
    private String response;
    private Long userId;
    private Long categoryId;
}
