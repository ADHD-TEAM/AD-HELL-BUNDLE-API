package com.adhd.ad_hell.domain.advertise.query.dto.response;


public class AdFileDto {
}
