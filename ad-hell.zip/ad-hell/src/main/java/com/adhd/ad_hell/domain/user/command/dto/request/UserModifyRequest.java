package com.adhd.ad_hell.domain.user.command.dto.request;


import lombok.Getter;

@Getter
public class UserModifyRequest {

    private String nickname;

}
