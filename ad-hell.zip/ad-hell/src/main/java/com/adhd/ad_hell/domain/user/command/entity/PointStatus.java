package com.adhd.ad_hell.domain.user.command.entity;

public enum PointStatus {
  VALID,
  COMPENSATED
}
