package com.adhd.ad_hell.domain.reward.command.domain.aggregate;

public enum RewardStockStatus {
  ACTIVATE,
  USED,
  EXPIRED,
  DELETE;
}
