package com.adhd.ad_hell;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdHellApplication {

	public static void main(String[] args) {
		SpringApplication.run(AdHellApplication.class, args);
	}

}
