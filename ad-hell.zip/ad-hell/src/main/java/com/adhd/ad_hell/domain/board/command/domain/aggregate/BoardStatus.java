package com.adhd.ad_hell.domain.board.command.domain.aggregate;

public enum BoardStatus {

    ACTIVE,         // 사용중
    DELETED         // 삭제(소프트 삭제 시)
}
