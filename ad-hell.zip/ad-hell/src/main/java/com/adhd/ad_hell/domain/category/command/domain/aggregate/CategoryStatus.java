package com.adhd.ad_hell.domain.category.command.domain.aggregate;

public enum CategoryStatus {
  ACTIVATE,
  DELETE
}
