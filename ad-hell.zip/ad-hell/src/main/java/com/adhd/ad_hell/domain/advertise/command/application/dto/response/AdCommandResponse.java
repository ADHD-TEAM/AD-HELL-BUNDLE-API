package com.adhd.ad_hell.domain.advertise.command.application.dto.response;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class AdCommandResponse {
    private Long adId;
}
