package com.adhd.ad_hell.domain.user.command.entity;

public enum PointType {
  VIEW,
  EARN,
  USE,
  COMPENSATION
}
