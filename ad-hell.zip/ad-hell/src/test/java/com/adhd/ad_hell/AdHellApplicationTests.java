package com.adhd.ad_hell;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdHellApplicationTests {

    @Test
    void contextLoads() {
    }

}
