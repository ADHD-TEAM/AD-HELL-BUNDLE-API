package com.adhd.ad_hell.domain.notification.command.application.service;

import com.adhd.ad_hell.domain.notification.command.application.dto.request.NotificationSendRequest;
import com.adhd.ad_hell.domain.notification.command.application.dto.response.NotificationDispatchResponse;
import com.adhd.ad_hell.domain.notification.command.domain.aggregate.Notification;
import com.adhd.ad_hell.domain.notification.command.domain.aggregate.NotificationTemplate;
import com.adhd.ad_hell.domain.notification.command.domain.aggregate.enums.NotificationTemplateKind;
import com.adhd.ad_hell.domain.notification.command.domain.aggregate.enums.YnType;
import com.adhd.ad_hell.domain.notification.command.domain.event.NotificationCreatedEvent;
import com.adhd.ad_hell.domain.notification.command.infrastructure.repository.JpaNotificationRepository;
import com.adhd.ad_hell.domain.notification.command.infrastructure.repository.JpaNotificationScheduleRepository;
import com.adhd.ad_hell.domain.notification.command.infrastructure.repository.JpaNotificationTemplateRepository;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.transaction.support.TransactionSynchronization;
import org.springframework.transaction.support.TransactionSynchronizationManager;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class NotificationCommandServiceSendNotificationTest {

    @Mock
    JpaNotificationRepository notificationRepo;

    @Mock
    JpaNotificationTemplateRepository templateRepo;

    @Mock
    JpaNotificationScheduleRepository scheduleRepo;

    @Mock
    PushPreferencePort pushPref;

    @Mock
    ApplicationEventPublisher publisher;

    @InjectMocks
    NotificationCommandService sut;

    @Test
    @DisplayName("PUSH_ENABLED 대상으로 공지 발송 시 푸시 ON 회원 수만큼 Notification이 저장되고 이벤트가 발행된다")
    void sendNotificationSuccess() {
        // --- given ---
        Long templateId = 1L;

        // 템플릿 엔티티
        NotificationTemplate template = NotificationTemplate.builder()
                .templateKind(NotificationTemplateKind.NORMAL)
                .templateTitle("{{name}}님, 공지입니다")
                .templateBody("안녕하세요 {{name}}님, 새로운 공지가 있습니다.")
                .deletedYn(YnType.no())
                .build();

        when(templateRepo.findById(templateId)).thenReturn(Optional.of(template));

        // 푸시 ON 회원 (예: 2명)
        Set<Long> enabledMembers = new HashSet<>(Arrays.asList(100L, 200L));
        when(pushPref.findAllEnabled()).thenReturn(enabledMembers);

        // saveAll 은 그대로 리스트를 반환하도록 설정 (ID는 null이지만 테스트에는 큰 영향 X)
        ArgumentCaptor<List<Notification>> saveAllCaptor = ArgumentCaptor.forClass(List.class);
        when(notificationRepo.saveAll(saveAllCaptor.capture()))
                .thenAnswer(invocation -> invocation.getArgument(0));

        // unread count stub (이벤트에서 사용할 값)
        when(notificationRepo.countByUserIdAndReadYn(100L, YnType.N)).thenReturn(3L);
        when(notificationRepo.countByUserIdAndReadYn(200L, YnType.N)).thenReturn(5L);

        // 요청 DTO (PUSH_ENABLED + 변수)
        NotificationSendRequest request = NotificationSendRequest.builder()
                .targetType(NotificationSendRequest.TargetType.PUSH_ENABLED)
                .variables(Map.of("name", "홍길동"))
                .build();

        // 트랜잭션 동기화 활성화 (afterCommit 테스트용)
        TransactionSynchronizationManager.initSynchronization();
        NotificationDispatchResponse response;
        try {
            // --- when ---
            response = sut.sendNotification(templateId, request);

            // 커밋 시점 콜백 수동 호출
            List<TransactionSynchronization> syncs =
                    new ArrayList<>(TransactionSynchronizationManager.getSynchronizations());
            syncs.forEach(TransactionSynchronization::afterCommit);
        } finally {
            TransactionSynchronizationManager.clearSynchronization();
        }

        // --- then ---

        // 1) 템플릿 조회 및 대상자 계산 확인
        verify(templateRepo, times(1)).findById(templateId);
        verify(pushPref, times(1)).findAllEnabled();

        // 2) Notification 생성/저장 검증
        List<Notification> savedList = saveAllCaptor.getValue();
        assertEquals(2, savedList.size(), "푸시 ON 회원 수만큼 Notification 이 생성되어야 한다.");

        // 제목/본문 variable merge 확인
        for (Notification n : savedList) {
            assertTrue(enabledMembers.contains(n.getUserId()));
            assertEquals("홍길동님, 공지입니다", n.getNotificationTitle());
            assertEquals("안녕하세요 홍길동님, 새로운 공지가 있습니다.", n.getNotificationBody());
            assertEquals(YnType.N, n.getReadYn(), "초기 readYn 은 N 이어야 한다.");
        }

        // 3) 응답 검증
        assertEquals(2, response.getRecipientCount(), "recipientCount 는 발송된 회원 수와 같아야 한다.");
        // ID는 stub 에서 세팅하지 않았으므로 null일 수 있음 (실제 JPA 환경에서는 값이 채워짐)
        // 여기서는 null 여부만 안전하게 체크하거나, 아예 검증하지 않을 수도 있음
        // assertNull(response.getNotificationId());

        // 4) 이벤트 발행 검증 (각 유저별 1회)
        ArgumentCaptor<Object> eventCaptor = ArgumentCaptor.forClass(Object.class);
        verify(publisher, times(2)).publishEvent(eventCaptor.capture());

        List<Object> events = eventCaptor.getAllValues();
        assertEquals(2, events.size());

        // 이벤트 타입 및 내용 검증
        Map<Long, Long> unreadByUser = new HashMap<>();
        unreadByUser.put(100L, 3L);
        unreadByUser.put(200L, 5L);

        for (Object ev : events) {
            assertTrue(ev instanceof NotificationCreatedEvent);
            NotificationCreatedEvent e = (NotificationCreatedEvent) ev;

            assertTrue(enabledMembers.contains(e.getUserId()), "이벤트의 userId 는 푸시 ON 회원이어야 한다.");
            assertEquals("홍길동님, 공지입니다", e.getTitle());
            assertEquals("안녕하세요 홍길동님, 새로운 공지가 있습니다.", e.getBody());

            // 우리가 stub 해둔 unreadCount 와 일치하는지
            assertEquals(unreadByUser.get(e.getUserId()), e.getUnreadCount());
        }
    }

    @Test
    @DisplayName("PUSH_ENABLED 대상이 없으면 Notification 을 저장하지 않고 recipientCount=0 을 반환한다")
    void sendNotificationNoRecipients() {
        // --- given ---
        Long templateId = 1L;

        NotificationTemplate template = NotificationTemplate.builder()
                .templateKind(NotificationTemplateKind.NORMAL)
                .templateTitle("공지 제목")
                .templateBody("공지 내용")
                .deletedYn(YnType.no())
                .build();

        when(templateRepo.findById(templateId)).thenReturn(Optional.of(template));
        when(pushPref.findAllEnabled()).thenReturn(Collections.emptySet());

        NotificationSendRequest request = NotificationSendRequest.builder()
                .targetType(NotificationSendRequest.TargetType.PUSH_ENABLED)
                .build();

        // 트랜잭션 동기화 활성화 (혹시라도 등록되는지 확인용)
        TransactionSynchronizationManager.initSynchronization();
        NotificationDispatchResponse response;
        try {
            // --- when ---
            response = sut.sendNotification(templateId, request);

            // --- then (동기화 목록 확인) ---
            assertTrue(TransactionSynchronizationManager.getSynchronizations().isEmpty(),
                    "대상이 없으면 afterCommit 콜백도 등록되지 않아야 한다.");
        } finally {
            TransactionSynchronizationManager.clearSynchronization();
        }

        // 1) 저장 안 됨
        verify(notificationRepo, never()).saveAll(anyList());
        // 2) 이벤트 발행 안 됨
        verify(publisher, never()).publishEvent(any());

        // 3) 응답 값 확인
        assertEquals(0, response.getRecipientCount());
        assertNull(response.getNotificationId(), "대상이 없으면 대표 notificationId는 null 이어야 한다.");
    }
}

